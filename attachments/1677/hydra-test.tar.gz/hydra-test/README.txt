This is a simple test program to reproduce a bug. The bug consists of remaining  hydra_pmi_proxy zoombie processes after the child process has exit.

The test consists of two programms. A parent program which spawns a child program within a loop. To reproduce the bug just run the parent programm in debug mode a few iterations of the loop and detect if there are remaining processes.

To compile each part just cd to the subdirectory and type "make itadbx"
I have compiled with the intel compiler.
