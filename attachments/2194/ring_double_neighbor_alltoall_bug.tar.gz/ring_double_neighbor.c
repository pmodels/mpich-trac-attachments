/****************************************************************
 *                                                              *
 * This file has been written as a sample solution to an        *
 * exercise in a course given at the High Performance           *
 * Computing Centre Stuttgart (HLRS).                           *
 * The examples are based on the examples in the MPI course of  *
 * the Edinburgh Parallel Computing Centre (EPCC).              *
 * It is made freely available with the understanding that      *
 * every copy of this file must include this header and that    *
 * HLRS and EPCC take no responsibility for the use of the      *
 * enclosed teaching material.                                  *
 *                                                              *
 * Authors: Joel Malard, Alan Simpson,            (EPCC)        *
 *          Rolf Rabenseifner, Traugott Streicher (HLRS)        *
 *                                                              *
 * Contact: rabenseifner@hlrs.de                                * 
 *                                                              *  
 * Purpose: A program to try MPI_Issend and MPI_Recv.           *
 *                                                              *
 * Contents: C-Source                                           *
 *                                                              *
 ****************************************************************/


#include <stdio.h>
#include <mpi.h>

#define tag_pos 201
#define tag_neg 199
#define max_dims 1 


int main (int argc, char *argv[])
{
  int my_rank, size;
  /* int snd_buf_pos, rcv_buf_pos, snd_buf_neg, rcv_buf_neg; */
  int snd_buf_arr[2];
   /* snd_buf_neg=snd_buf_arr[0], snd_buf_pos=snd_buf_arr[1] */
  int rcv_buf_arr[2];
   /* rcv_buf_pos=rcv_buf_arr[0], rcv_buf_neg=rcv_buf_arr[1] */
  int right, left;
  int sum_pos, sum_neg, sum_expected, i;

  MPI_Status  status;
  MPI_Request request_pos, request_neg;

  MPI_Comm    new_comm;
  int         dims[max_dims], periods[max_dims], reorder;

  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  /* Set cartesian topology. */
  dims[0] = size;
  periods[0] = 1;
#ifdef NOPERIOD
  periods[0] = 0;
#endif
  reorder = 1;
 
  MPI_Cart_create(MPI_COMM_WORLD, max_dims, dims, periods, reorder, &new_comm);
  MPI_Comm_rank(new_comm, &my_rank);

  /* Get nearest neighbour rank. */
  MPI_Cart_shift(new_comm, 0, 1, &left, &right);

  sum_pos = 0;   snd_buf_arr[1]/*pos*/ = +(1000+my_rank);
  sum_neg = 0;   snd_buf_arr[0]/*neg*/ = -(1000+my_rank);

  for( i = 0; i < size; i++) 
  {
    rcv_buf_arr[1]/*neg*/ = 0;  rcv_buf_arr[0]/*pos*/ = 0;
    printf("[sort=%03d.0.%03d] i=%03d my_rank=%03d: snd_buf_pos/neg=%5d,%5d rcv_buf_neg/pos=%5d,%5d before communication\n",
                  i,  my_rank, i,     my_rank,      snd_buf_arr[1]/*pos*/,snd_buf_arr[0]/*neg*/, rcv_buf_arr[1]/*neg*/,rcv_buf_arr[0]/*pos*/);

    // MPI_Issend(&snd_buf_arr[1]/*pos*/, 1, MPI_INT, right, tag_pos, new_comm, &request_pos);
    // MPI_Issend(&snd_buf_arr[0]/*neg*/, 1, MPI_INT, left,  tag_neg, new_comm, &request_neg);
    // MPI_Recv(&rcv_buf_arr[0]/*pos*/, 1, MPI_INT, left,  tag_pos, new_comm, &status);
    // MPI_Recv(&rcv_buf_arr[1]/*neg*/, 1, MPI_INT, right, tag_neg, new_comm, &status);
    // MPI_Wait(&request_pos, &status);
    // MPI_Wait(&request_neg, &status);

    MPI_Neighbor_alltoall(snd_buf_arr, 1, MPI_INT, rcv_buf_arr, 1, MPI_INT, new_comm);
#ifdef WORKAROUND
    if((size<=2) && (periods[0]==1)){int tmp; tmp=rcv_buf_arr[0];  rcv_buf_arr[0]=rcv_buf_arr[1];  rcv_buf_arr[1]=tmp;} /*i.e., repair bug in MPI*/ 
#endif

    printf("[sort=%03d.1.%03d] i=%03d my_rank=%03d: snd_buf_pos/neg=%5d,%5d rcv_buf_neg/pos=%5d,%5d after  communication\n",
                  i,  my_rank, i,     my_rank,      snd_buf_arr[1]/*pos*/,snd_buf_arr[0]/*neg*/, rcv_buf_arr[1]/*neg*/,rcv_buf_arr[0]/*pos*/);
    
    snd_buf_arr[1]/*pos*/ = rcv_buf_arr[0]/*pos*/;
    sum_pos += rcv_buf_arr[0]/*pos*/;
    
    snd_buf_arr[0]/*neg*/ = rcv_buf_arr[1]/*neg*/;
    sum_neg += rcv_buf_arr[1]/*neg*/;
  }

  if(periods[0])
  {
    sum_expected = 1000*size + size*(size-1)/2;
    printf ("[sort=999.-.%03d]        my_rank=%03i: sum_pos = %i (expected=%i), sum_neg = %i (expected=%i)", 
                      my_rank,        my_rank,      sum_pos, +sum_expected,     sum_neg, -sum_expected);
    if ((sum_pos != +sum_expected) || (sum_neg != -sum_expected)) printf (" WRONG RESULT(S)!!!"); 
  } else { /* checking only for pos/neg */
    printf ("[sort=999.-.%03d]        my_rank=%03i: sum_pos = %i, sum_neg = %i", 
                      my_rank,        my_rank,      sum_pos,      sum_neg);
    if ((sum_pos < 0 ) || (sum_neg > 0)) printf (" WRONG RESULT(S)!!!"); 
  }
  printf ("\n");

  MPI_Finalize();
}
