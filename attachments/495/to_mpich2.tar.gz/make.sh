#!/bin/sh


MPI_ROOT=/opt/mpich2
MPI_INCL="-I$MPI_ROOT/include"
MPI_LIBS="-L$MPI_ROOT/lib -lmpich -lpthread -lrt -i-static"

ifort $MPI_INCL helloworld.f -o helloworld.exe $MPI_LIBS
ifort $MPI_INCL rekenprog.f -o rekenprog.exe $MPI_LIBS
ifort $MPI_INCL master.f -o master.exe $MPI_LIBS
