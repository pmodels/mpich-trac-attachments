#!/bin/sh

mpdboot -n 2 -f hostfile
mpiexec -n 1 master.exe | tee test.tmp
mpdallexit

#
# sort/concatenate output per process
#
if [ 1 == 1 ]; then
   rm -f test.out
   for iprc in 0 10 11 20 21 22 23 24; do
      echo "---------------------------------------------------------------------------" | tee -a test.out
      grep "^ *$iprc :" test.tmp | tee -a test.out
   done
fi
