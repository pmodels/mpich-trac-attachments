#!/usr/bin/perl -w
# Script to change runtime libraries from MTd to MD or MDd
# Finds all vcproj-files and adjusts entry.
use strict;
use File::Find;

sub wanted
{
   if ( not -d and m/\.vcproj$/ )
   {
      my $file=$_;
      my $changed=0;

      open (OUTFILE,">$_-mba.tmp") or die("could not open $_-/bre.tmp\n");
      open (INFILE,"$_") or die("could not open $_\n");
      while (<INFILE>)
      {
	if (s/(RuntimeLibrary=)"0"/$1"2"/ or s/(RuntimeLibrary=)"1"/$1"3"/)
	  {
	    $changed=1;
	  }
         print OUTFILE;
      }
      close (OUTFILE);
      close (INFILE);
      rename "$file-mba.tmp", $file;
      if ($changed)
	{
	  print "$file changed\n";
	}
   }
}
                                
find(\&wanted,'.');
