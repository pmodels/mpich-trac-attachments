#!/bin/bash
pwd
cd "${1}"
pwd
cd maint
perl update_windows_version 1.0.8
cd -
perl maint/extracterrmsgs -skip=src/util/multichannel/mpi.c src/mpi src/nameserv src/util src/binding src/include src/mpid src/pmi > defmsg_h.log
perl mbaChangeRuntimeLibrary.pl

