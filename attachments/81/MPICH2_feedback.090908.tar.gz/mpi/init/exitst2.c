/* -*- Mode: C; c-basic-offset:4 ; -*- */
/*
 *  (C) 2001 by Argonne National Laboratory.
 *      See COPYRIGHT in top-level directory.
 */
#include "mpi.h"
#include <stdio.h>

/* 
 * This is a special test to check that mpiexec handles zero/non-zero 
 * return status from an application.  In this case, each process 
 * returns a different return status
 */
int main( int argc, char *argv[] )
{
    int rank;
    int errs = 0;
    MTest_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MTest_Finalize( errs );
    MPI_Finalize( );
    return rank;
}
