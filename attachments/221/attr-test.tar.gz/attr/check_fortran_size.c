#include <stdio.h>
#include <mpi.h>

int main(int argc, char* argv[])
{
    int size;

    FILE *fp = fopen("attr_f.h", "w");
    if (NULL == fp) {
        return 1;
    }
    fprintf(fp, "#define FORTRAN_TEST_AINT_INTEGER integer*%d\n", 
            sizeof(void*));
    fclose(fp);
    return 0;
}
