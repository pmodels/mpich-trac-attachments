use strict;
use warnings;

package TestNet::Server::Main;

use Bot::Net::Server;
use Bot::Net::Mixin::Server::IRC;

1;
